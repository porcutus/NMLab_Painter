import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;


public class CanvasPanel extends JPanel implements MouseListener, MouseMotionListener{
	
	public String fileName;
	private JPanel sizeBoxRight = new JPanel();
	private JPanel sizeBoxDiagonal = new JPanel();
	private JPanel sizeBoxBottom = new JPanel();
	private int[] width = new int[1000];
	private int[] height = new int[1000];
	private int count = 0;
	public ArtBlock artBlock;
	
	public CanvasPanel(JLabel label){
		Border border = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
		
		this.setPreferredSize(new Dimension(1200, 625));
		this.setBorder(border);
		this.setBackground(Color.GRAY);
		this.setLayout(null);
		artBlock = (ArtBlock) label;
		artBlock.setBounds(0, 0, artBlock.getBufWidth(), artBlock.getBufHeight() );
		artBlock.setOpaque(true);
		this.add(artBlock);
		
		width[0] = artBlock.getBufWidth();
		height[0] = artBlock.getBufHeight();
		sizeBoxRight.setBounds(new Rectangle(artBlock.getBufWidth(),artBlock.getBufHeight()/2,10,10));
		sizeBoxDiagonal.setBounds(new Rectangle(artBlock.getBufWidth(), artBlock.getBufHeight(),10,10));
		sizeBoxBottom.setBounds(new Rectangle(artBlock.getBufWidth()/2,artBlock.getBufHeight(),10,10));
		
		sizeBoxRight.setBackground(Color.BLUE);
		sizeBoxDiagonal.setBackground(Color.BLUE);
		sizeBoxBottom.setBackground(Color.BLUE);
		
		sizeBoxRight.setOpaque(true);
		sizeBoxDiagonal.setOpaque(true);
		sizeBoxBottom.setOpaque(true);
		
		this.add(sizeBoxRight);
		this.add(sizeBoxDiagonal);
		this.add(sizeBoxBottom);
		
		sizeBoxRight.addMouseListener(this);
		sizeBoxDiagonal.addMouseListener(this);
		sizeBoxBottom.addMouseListener(this);
	}
	
	public void undo(){
		artBlock.undo();
		reposSizeBox();
	}
	
	public void redo(){
		artBlock.redo();
		reposSizeBox();
	}
	
	public void saveSize(){
		count++;
		width[count] = artBlock.getBufWidth();
		height[count] = artBlock.getBufHeight();
	}
	public void reposSizeBox(){
		sizeBoxRight.setBounds(new Rectangle(artBlock.getBufWidth(),artBlock.getBufHeight()/2,10,10));
		sizeBoxDiagonal.setBounds(new Rectangle(artBlock.getBufWidth(), artBlock.getBufHeight(),10,10));
		sizeBoxBottom.setBounds(new Rectangle(artBlock.getBufWidth()/2,artBlock.getBufHeight(),10,10));
	}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {
		if(e.getSource() == sizeBoxRight){
			sizeBoxRight.setBounds(new Rectangle(artBlock.getBufWidth() + e.getX(),artBlock.getBufHeight()/2,10,10));
			artBlock.resizeBufImg(artBlock.getBufWidth() + e.getX(), artBlock.getBufHeight());
		}
		else if(e.getSource() == sizeBoxDiagonal){
			sizeBoxDiagonal.setBounds(new Rectangle(artBlock.getBufWidth() + e.getX(), artBlock.getBufHeight() + e.getY(), 10, 10));
			artBlock.resizeBufImg(artBlock.getBufWidth() + e.getX(), artBlock.getBufHeight() + e.getY());
		}
		else if(e.getSource() == sizeBoxBottom){
			sizeBoxBottom.setBounds(new Rectangle(artBlock.getBufWidth(), artBlock.getBufHeight() + e.getY(), 10, 10));
			artBlock.resizeBufImg(artBlock.getBufWidth(), artBlock.getBufHeight() + e.getY());
		}
		artBlock.setBounds(0, 0, artBlock.getBufWidth(), artBlock.getBufHeight() );
		reposSizeBox();
		saveSize();
	}
	public void mouseDragged(MouseEvent e) {}
	public void mouseMoved(MouseEvent arg0) {}
}
