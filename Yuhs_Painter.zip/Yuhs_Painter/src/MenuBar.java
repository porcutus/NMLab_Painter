import java.awt.BorderLayout;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


public class MenuBar extends JMenuBar{
	
	JMenu fileMenu = new JMenu("File");
	JMenu editMenu = new JMenu("Edit");
	JMenu windowsMenu = new JMenu("Windows");
	JMenu helpMenu = new JMenu("Help");
	
	JMenuItem newItem = new JMenuItem("New");
	JMenuItem saveItem = new JMenuItem("Save");
	JMenuItem saveAsItem = new JMenuItem("Save As");
	
	JMenuItem aboutItem = new JMenuItem("About");
	
		public MenuBar(){

			this.add(fileMenu);
			this.add(editMenu);
			this.add(windowsMenu);
			this.add(helpMenu);
		
			fileMenu.add(newItem);
			fileMenu.add(saveItem);
			fileMenu.add(saveAsItem);
		
			helpMenu.add(aboutItem);
		}
		
		public JMenuItem getSaveAs(){
			return saveAsItem;
		}
		public JMenuItem getSave(){
			return saveItem;
		}
}
