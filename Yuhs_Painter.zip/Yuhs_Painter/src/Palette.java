import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Line2D;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;


public class Palette extends JPanel implements MouseListener{

	private int rgb[][]={
			{0,255,128,192,128,255,128,255,  0,  0,  0,  0,  0,  0,128,255,128,255,  0,  0,  0,128,  0,128,128,255,128,255,255,255,255,255},
			{0,255,128,192,  0,  0,128,255,128,255,128,255,  0,  0,  0,  0,128,255, 64,255,128,255, 64,128,  0,  0, 64,128,255,255,255,255},
			{0,255,128,192,  0,  0,  0,  0,  0,  0,128,255,128,255,128,255, 64,128, 64,128,255,255,128,255,255,128,  0, 64,255,255,255,255}
	};
	private JPanel chosen = new JPanel();
	private Color currentColor = new Color(rgb[0][0],rgb[1][0],rgb[2][0]);
	
	public Palette(){
		//Border�y��
		final Border raisedetched;
		raisedetched = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);

		//���j�~��
		JPanel displayBox = new JPanel();
		displayBox.setLayout(null);
		displayBox.setBounds(new Rectangle(2, 2, 30, 30));
		displayBox.setBorder(raisedetched);
		//�ثe����
//		JPanel chosen = new JPanel();
		chosen.setLayout(null);
		chosen.setBounds(new Rectangle(5, 5, 15, 15));
		chosen.setBackground(Color.BLACK);
		JPanel boxC = new JPanel();
		boxC.setLayout(new GridLayout(1,1));
		boxC.setBounds(new Rectangle(5, 5, 15, 15));
		boxC.add(chosen);
		displayBox.add(boxC);
		boxC.setBorder(raisedetched);
		//���e����
		JPanel prev = new JPanel();
		prev.setLayout(null);
		prev.setBounds(new Rectangle(10, 10, 15, 15));
		prev.setBackground(Color.WHITE);
		JPanel boxP = new JPanel();
		boxP.setLayout(new GridLayout(1,1));
		boxP.setBounds(new Rectangle(10, 10, 15, 15));
		boxP.add(prev);
		displayBox.add(boxP);
		boxP.setBorder(raisedetched);
		this.add(displayBox);
			
		//�Ҧ����
		for(int j = 0 ; j < rgb[0].length ; j++){
			JPanel color = new JPanel();
			color.setLayout(new GridLayout(1,1));
			color.setBounds(new Rectangle(2, 2, 15, 15));
			color.setBackground(new Color(rgb[0][j],rgb[1][j],rgb[2][j]));
			JPanel box = new JPanel();
			box.setLayout(new GridLayout(1,1));
			if(j % 2 == 0){
				box.setBounds(new Rectangle(35+15*(j/2), 2, 15, 15));
			}
			else{
				box.setBounds(new Rectangle(35+15*(j/2), 17, 15, 15));
			}
			box.add(color);
			this.add(box, BorderLayout.SOUTH);
			box.setBorder(raisedetched);
		}
		
		this.addMouseListener(this);
	}
	//end of constructor
	
	public Color getCurrentColor(){
		return currentColor;
	}
	
	public void mouseClicked(MouseEvent e) {
		int j = (e.getX()-35)/15*2 + e.getY()/17;
		currentColor = new Color(rgb[0][j],rgb[1][j],rgb[2][j]);
		chosen.setBackground(new Color(rgb[0][j],rgb[1][j],rgb[2][j]));
	}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}
