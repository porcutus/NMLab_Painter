//
//import java.awt.Component;
//import javax.swing.*;
//import javax.swing.border.Border;
//import javax.swing.table.TableCellRenderer;
//
//public class Test {
//
//   public static void main(String[] args) {
//      SwingUtilities.invokeLater(new Runnable() {
//
//         @Override
//         public void run() {
//            new Test().makeUI();
//         }
//      });
//   }
//
//   public void makeUI() {
//      Object[][] data = {{"One", Boolean.TRUE},
//         {"Two", Boolean.FALSE}
//      };
//      Object[] headers = {"String", "Boolean"};
//      JTable table = new JTable(data, headers) {
//
//         Border border = BorderFactory.createEtchedBorder();
//
//         @Override
//         public Class<?> getColumnClass(int column) {
//            return column == 0 ? String.class : Boolean.class;
//         }
//
//         @Override
//         public Component prepareRenderer(TableCellRenderer renderer, int row,
//                 int column) {
//            JComponent c = (JComponent) super.prepareRenderer(renderer, row,
//                    column);
//            c.setBorder(border);
//            return c;
//         }
//      };
//
//      JFrame frame = new JFrame("");
//      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//      frame.setSize(400, 400);
//      frame.setLocationRelativeTo(null);
//      frame.add(new JScrollPane(table));
//      frame.setVisible(true);
//   }
//}

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.EventObject;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;


public class Painter extends JFrame implements MouseListener{

	public static void main(String[] args){
		Painter painter = new Painter();
		painter.setVisible(true);
	}

	private Toolbar toolbar;
	private Palette palette;
	private CanvasPanel cp;
	private MenuBar menuBar;
	
	public Painter(){
		super();
		setSize(800,800);
		getContentPane().setLayout(new BorderLayout());

		//Border�y��
		Border blackline;
		final Border raisedetched;
		Border loweredetched, raisedbevel, loweredbevel, empty;
		blackline = BorderFactory.createLineBorder(Color.black);
		raisedetched = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
		loweredetched = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
		raisedbevel = BorderFactory.createRaisedBevelBorder();
		loweredbevel = BorderFactory.createLoweredBevelBorder();
		empty = BorderFactory.createEmptyBorder();
		
		//�u��C
		menuBar = new MenuBar();
		getContentPane().add(menuBar, BorderLayout.NORTH);

		//�u��c
		toolbar = new Toolbar();
		getContentPane().add(toolbar, BorderLayout.EAST);
		
		//�զ�L
		palette = new Palette();
		palette.setLayout(null);
		palette.setPreferredSize(new Dimension(30,50));
//		container.setBorder(raisedetched);
		getContentPane().add(palette, BorderLayout.SOUTH);
		
		//�e��
		ArtBlock a = new ArtBlock(palette, toolbar);
		cp = new CanvasPanel(a);
		this.add(cp, BorderLayout.WEST);
		
		toolbar.getBtnUndo().addMouseListener(this);
		toolbar.getBtnRedo().addMouseListener(this);
		menuBar.getSaveAs().addMouseListener(this);
		menuBar.getSave().addMouseListener(this);
	}
	//end of constructor
	
	//saveAs
	public void save(){
		FileDialog fileDialog = new FileDialog( new Frame() , "�Ы��w�@���ɦW", FileDialog.SAVE );
		fileDialog.setVisible(true);
		if(fileDialog.getFile()==null) return;
		cp.fileName = fileDialog.getDirectory()+fileDialog.getFile();
	}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		if(e.getSource() == toolbar.getBtnUndo()){
			cp.undo();
		}
		else if(e.getSource() == toolbar.getBtnRedo()){
			cp.redo();
		}
		else if(e.getSource() == menuBar.getSaveAs()){
			save();
			try{
				int dotpos = cp.fileName.lastIndexOf('.');
				ImageIO.write(cp.artBlock.bufImg, cp.fileName.substring(dotpos + 1), new File(cp.fileName));
			}
			catch(IOException even) {
				JOptionPane.showMessageDialog(null, even.toString(),"�L�k�x�s����", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(e.getSource() == menuBar.getSave()){
			if(cp.fileName == null){
				save();
			}
			else{
				try{
					int dotpos = cp.fileName.lastIndexOf('.');
					ImageIO.write(cp.artBlock.bufImg, cp.fileName.substring(dotpos + 1), new File(cp.fileName));
				}
				catch(IOException even) {
					JOptionPane.showMessageDialog(null, even.toString(),"�L�k�x�s����", JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
	public void mouseReleased(MouseEvent e) {}
}
