import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;


public class Toolbar extends JPanel implements MouseListener{

	private int penWidth;
	private JTextField txtPenWidth;
	private JButton[] tools = new JButton[12];//tools[12]�]�w���e�ʲ�
	JButton btnPenWidth = new JButton();
	private String currentTool = "pencil";
	
	public Toolbar(){
			this.setPreferredSize(new Dimension(150, 200));
			this.setLayout(new FlowLayout());
			Border border = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
			this.setBorder(border);
			//tools[0~9]
			for(int i = 0 ; i < 10 ; i++){
				ImageIcon img = new ImageIcon("img/tool" + (i+1) + ".gif");
				tools[i] = new JButton(img);
				tools[i].addMouseListener(this);
				this.add(tools[i]);
			}
			//tools[10~11]
			tools[10] = new JButton("Click to Undo");
			tools[10].addMouseListener(this);
			this.add(tools[10]);
			tools[11] = new JButton("Click to Redo");
			tools[11].addMouseListener(this);
			this.add(tools[11]);
			txtPenWidth = new JTextField("1");
			txtPenWidth.setPreferredSize(new Dimension(50,25));
			txtPenWidth.setHorizontalAlignment(JTextField.CENTER);
			JLabel label = new JLabel("Pen Size");
			this.add(label);
			this.add(txtPenWidth);
			
			tools[0].setName("line");
			tools[1].setName("rectangle");
			tools[2].setName("ellipse");
			tools[3].setName("roundRec");
			tools[4].setName("pencil");
			tools[5].setName("eraser");
			tools[6].setName("beiz");
			tools[7].setName("fan");
			tools[8].setName("polygon");
			tools[9].setName("text");
			tools[10].setName("undo");
			tools[11].setName("redo");
			
			for(int i = 6 ; i < 10 ; i++){
				tools[i].setEnabled(false);
			}
	}
	
	public JButton getBtnUndo(){
		return tools[10];
	}
	
	public JButton getBtnRedo(){
		return tools[11];
	}
	
	public int getPenWidth(){
		penWidth = Integer.valueOf(txtPenWidth.getText());
		return penWidth;
	}
	
	public String getCurrentTool(){
		return currentTool;
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		for(int i = 0 ; i < 12 ; i++){
			if(e.getSource() == tools[i]){
				currentTool = tools[i].getName();
				if(currentTool.equals("eraser")){
					txtPenWidth.setText("25");
				}
				else if(currentTool.equals("pencil")){
					txtPenWidth.setText("1");
				}
				return;
			}
		}
		currentTool = "pencil";
	}
	public void mouseReleased(MouseEvent e) {}
}
