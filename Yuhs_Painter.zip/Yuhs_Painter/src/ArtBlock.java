import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Arc2D;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;


public class ArtBlock extends JLabel implements MouseListener, MouseMotionListener {
	private int bufferedWidth = 500;
	private int bufferedHeight = 500;
	Palette palette;
	Toolbar toolbar;
	private String currentTool = "pencil";
	public BufferedImage bufImg = new BufferedImage(bufferedWidth, bufferedHeight,BufferedImage.TYPE_3BYTE_BGR);
	private BufferedImage bufImgTemp;
	private BufferedImage savedBufImg[] = new BufferedImage[1000];
	private int count = 0;
	private Graphics2D actualCanvas = (Graphics2D) bufImg.getGraphics();
	private Graphics2D actualCanvasTemp;
	//�y��
	private Arc2D.Double shpArc = new Arc2D.Double();//����
	private Line2D.Double shpLine = new Line2D.Double();//���u
	private Ellipse2D.Double shpEllipse = new Ellipse2D.Double();//���
	private Rectangle2D.Double shpRec = new Rectangle2D.Double();//�x��
	private CubicCurve2D.Double shpBeiz = new CubicCurve2D.Double();//���󦱽u
	private RoundRectangle2D.Double shpRoundRec = new RoundRectangle2D.Double();//�ꨤ�x��
	private Point2D.Double shpPoint = new Point2D.Double();
	private Polygon polygon;//�h�䫬
	Shape shape = shpLine;
	private int x1 = 0;
	private int x2 = 0;
	private int y1 = 0;
	private int y2 = 0;
	private int originalRgb;
	
	ArtBlock(Palette palette, Toolbar toolbar){
		Border border = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
		this.setBorder(border);
		//�e����
//		bufImgTemp = new BufferedImage(bufferedWidth, bufferedHeight, BufferedImage.TYPE_INT_ARGB);
		this.setIcon(new ImageIcon(bufImg));
//		this.setIcon(new ImageIcon(bufImgTemp));
		//�N�e�����m��JLabel���W��
		this.setLayout(null);
		this.setVerticalAlignment(SwingConstants.TOP);
		this.setHorizontalAlignment(SwingConstants.LEFT);
		//�e��
//		actualCanvasTemp = (Graphics2D) bufImgTemp.getGraphics();
		actualCanvas.setPaint(Color.ORANGE);
		actualCanvas.fill(new Rectangle2D.Double(0,0,bufferedWidth,bufferedHeight));
//		actualCanvasTemp.setBackground(new Color(255,255,255,0));
//		actualCanvasTemp.clearRect(0,0,bufferedWidth,bufferedHeight);

		saveCanvas();
		
		this.palette = palette;
		this.toolbar = toolbar;
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}
	
	public void fillBucket(int x, int y, int fillColor){
		if (bufImg.getRGB(x, y) == originalRgb)// �C��@�ˤ~flood
			{
				bufImg.setRGB(x, y, fillColor);
				
		        fillBucket(x+1, y, fillColor);
		        fillBucket(x-1, y, fillColor);
		        fillBucket(x, y+1, fillColor);
		        fillBucket(x, y-1, fillColor);
		    }
	}
	
	public BufferedImage getBufImg(){
		return bufImg;
	}
	
	public int getBufWidth(){
		return bufferedWidth;
	}
	
	public int getBufHeight(){
		return bufferedHeight;
	}
	
	public void resizeBufImg(int width, int height){
		bufferedWidth = width;
		bufferedHeight = height;
		bufImg = new BufferedImage(bufferedWidth, bufferedHeight, BufferedImage.TYPE_3BYTE_BGR);
		this.setIcon(new ImageIcon(bufImg));
		Graphics2D graphics = (Graphics2D) bufImg.getGraphics();
		graphics.setPaint(Color.ORANGE);
		graphics.fill(new Rectangle2D.Double(0,0,bufferedWidth,bufferedHeight));
		graphics.drawImage(savedBufImg[count],0,0,this);
		saveCanvas();
	}
	//�N��l�e�������_�ӡA��undo�ϥ�
	public void saveCanvas(){
		//�� savedBufImg[0]�x�s�@�}�l�����A
		if(savedBufImg[0] != null){
			count++;
		}
		savedBufImg[count] = new BufferedImage(bufferedWidth, bufferedHeight,BufferedImage.TYPE_3BYTE_BGR);
		Graphics2D gphcSavedBufImg = (Graphics2D) savedBufImg[count].getGraphics();
		gphcSavedBufImg.drawImage(bufImg,0,0,this);
	}
	
	public void undo(){
		if(count>0){
			count--;
		}
		
		bufferedWidth = savedBufImg[count].getWidth();
		bufferedHeight = savedBufImg[count].getHeight();
//		drawPanel.setSize(draw_panel_width,draw_panel_height);

		bufImg = new BufferedImage(bufferedWidth, bufferedHeight,BufferedImage.TYPE_3BYTE_BGR);
		this.setIcon(new ImageIcon(bufImg));//�bJLabel�W��mbufImg�A�Ψ�ø��
		this.setBounds(new Rectangle(0, 0, bufferedWidth, bufferedHeight));
		
		Graphics2D g2d_bufImg = (Graphics2D) bufImg.getGraphics();
		g2d_bufImg.setPaint(Color.white);
		g2d_bufImg.fill(new Rectangle2D.Double(0,0,bufferedWidth,bufferedHeight));
		g2d_bufImg.drawImage(savedBufImg[count],0,0,this);
	}
	
	public void redo(){
		if(savedBufImg[count+1] != null){
			count++;
		}
		else{
			return;
		}
		
		bufferedWidth = savedBufImg[count].getWidth();
		bufferedHeight = savedBufImg[count].getHeight();
//		drawPanel.setSize(draw_panel_width,draw_panel_height);

		bufImg = new BufferedImage(bufferedWidth, bufferedHeight,BufferedImage.TYPE_3BYTE_BGR);
		this.setIcon(new ImageIcon(bufImg));//�bJLabel�W��mbufImg�A�Ψ�ø��
		this.setBounds(new Rectangle(0, 0, bufferedWidth, bufferedHeight));
		
		Graphics2D g2d_bufImg = (Graphics2D) bufImg.getGraphics();
		g2d_bufImg.setPaint(Color.white);
		g2d_bufImg.fill(new Rectangle2D.Double(0,0,bufferedWidth,bufferedHeight));
		g2d_bufImg.drawImage(savedBufImg[count],0,0,this);
	}
	
	public void drawShape(){
		Graphics2D graphics = (Graphics2D) bufImg.getGraphics();
		if(currentTool.equals("eraser")){
			graphics.setPaint(Color.ORANGE);
			graphics.setStroke( new BasicStroke( toolbar.getPenWidth(),  BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER) );
		}
		else{
			graphics.setPaint(palette.getCurrentColor());
			graphics.setStroke( new BasicStroke( toolbar.getPenWidth(),  BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER) );
		}
		graphics.draw(shape);
		repaint();
		
		//�s�W�@�iBufferedImage���A��bufImg_data[count]�A�ñNbufImgø�s��bufImg_data[count]//
		if(!(currentTool.equals("pencil")||currentTool.equals("eraser"))){
			saveCanvas();
		}
	}
	
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		currentTool = toolbar.getCurrentTool();
		x1 = e.getX();
		y1 = e.getY();
		//���e�@�I�s�_�ӡA����drag���ĪG�ɤ~���|�٭��W�@�ӵ��e!
		shape = shpLine;
		shpLine.setLine(x1, y1, x1, y1);
		drawShape();
	}
	public void mouseReleased(MouseEvent e) {
		x2=e.getX();
		y2=e.getY();
		if(currentTool.equals("line")){
			shape = shpLine;
			shpLine.setLine(x1, y1, x2, y2);
			undo();
			drawShape();
		}
		else if(currentTool.equals("rectangle")){
			shape = shpRec;
			shpRec.setRect(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x1-x2),Math.abs(y1-y2));
			undo();
			drawShape();
		}
		else if(currentTool.equals("ellipse")){
			shape = shpEllipse;
			shpEllipse.setFrame(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x1-x2),Math.abs(y1-y2));
			undo();
			drawShape();
		}
		else if(currentTool.equals("roundRec")){
			shape = shpRoundRec;
			shpRoundRec.setRoundRect(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x1-x2),Math.abs(y1-y2), 20.0f, 20.0f);
			undo();
			drawShape();
		}
		else if(currentTool.equals("text")){
			JTextField txt = new JTextField();
			txt.setBounds(x1,y1 - 15,100,30);
			txt.setOpaque(false);
			this.add(txt);
		}
		else{
			saveCanvas();
		}
	}
	public void mouseDragged(MouseEvent e) {
		x2=e.getX();
		y2=e.getY();
		//draw method
		if(currentTool.equals("eraser")||currentTool.equals("pencil")){
			shape = shpLine;
			shpLine.setLine(x1, y1, x2, y2);
			drawShape();
			x1 = e.getX();
			y1 = e.getY();
		}
		else if(currentTool.equals("line")){
			shape = shpLine;
			shpLine.setLine(x1, y1, x2, y2);
			undo();
			drawShape();
		}
		else if(currentTool.equals("rectangle")){
			shape = shpRec;
			shpRec.setRect(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x1-x2),Math.abs(y1-y2));
			undo();
			drawShape();
		}
		else if(currentTool.equals("ellipse")){
			shape = shpEllipse;
			shpEllipse.setFrame(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x1-x2),Math.abs(y1-y2));
			undo();
			drawShape();
		}
		else if(currentTool.equals("roundRec")){
			shape = shpRoundRec;
			shpRoundRec.setRoundRect(Math.min(x1, x2),Math.min(y1, y2),Math.abs(x1-x2),Math.abs(y1-y2), 20.0f, 20.0f);
			undo();
			drawShape();
		}
	}
	public void mouseMoved(MouseEvent e) {
		
	}
}
